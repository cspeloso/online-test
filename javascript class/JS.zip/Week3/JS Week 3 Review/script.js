window.addEventListener("load", init);

//Array of people
var people;

//HTML Elements (enter = submitBtn)
var firstName, lastName, enter, output;

function init(e)
{
	people = [];
	console.log(people);
	
	firstName = document.querySelector("input[name = 'firstName']");
	lastName = document.querySelector("input[name = 'lastName']");
	enter = document.querySelector("#submit");
	output = document.querySelector("#output");
	
	lastName.style.backgroundColor="lightblue";
	firstName.placeholder = "anis";
	firstName.style.fontFamily="jokerman";
	
	enter.addEventListener("click", add);
}

function add()
{	
	var person = {first:firstName.value,
					last:lastName.value
				};
				
	
	
	people.push(person);
	console.log(people);
	
	output.innerHTML = "";
	
	for(var i=0;i<people.length;i++)
	{
		output.innerHTML += "<p>";
		for(value in people[i])
		{
			//output.innerHTML += "<p>" + people[i].first + " " + people[i].last + "</p>";
			output.innerHTML += people[i][value];
			output.innerHTML += " ";
		}
		output.innerHTML += "</p>";
	}

}






































































/*window.addEventListener("load", init);

var buttons, people;

function init(e)
{

	people=[];
	buttons={};
	
	buttons.first = document.querySelector("input[name='firstName']");
	buttons.last = document.querySelector("input[name='lastName']");
	buttons.submit = document.querySelector("#submit");
	buttons.output = document.querySelector("#output");
	
	buttons.submit.addEventListener("click", addName);	
	
}

function addName(e)
	{
		people.push({firstName:buttons.first.value, lastName:buttons.last.value});
		console.log(people);
		
		var str = "";
		for(var i=0; i < people.length; i++)
		{
			for(value in people[i])
			{
				str+=people[i][value];
				str+=" ";  
			}
			str+= "<br>";
		}
		output.innerHTML += str;
	}*/