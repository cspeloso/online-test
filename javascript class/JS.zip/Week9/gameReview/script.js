//javascript file
console.log(reviews);

var reviewsLength = reviews.length;

var reviewsString = "";

var tableHTML = document.getElementById("reviewsBody");

var gameImg = document.getElementById("gameImage");

var gameTitle = "";

var console = "";

var rating = "";

var score = "";

for(i = 0; i < reviewsLength; i++)
{	
	reviewsString += "<tr>";
	
	
	reviewsString += "<th class = \"review\" onclick=\"clickFunc\">";
	reviewsString += reviews[i].gameTitle;
	reviewsString += "</th>";
	
	reviewsString += "<th>";
	reviewsString += reviews[i].consoles;
	reviewsString += "</th>";
	
	reviewsString += "<th>";
	reviewsString += reviews[i].rating;
	reviewsString += "</th>";
	
	reviewsString += "<th>";
	reviewsString += reviews[i].score;
	reviewsString += "</th>";
	
	reviewsString += "</tr>";
	
	
	reviewsBody.innerHTML += reviewsString;
}

var reviewsClass = document.getElementsByClassName("review");
console.log(reviewsClass);


function clickFunc()
{
	console.log("test");
}







































