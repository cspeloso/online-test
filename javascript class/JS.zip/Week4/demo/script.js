var canvas = document.querySelector("#canvas");
var context = canvas.getContext("2d");

//frames per second. 1000 / 60 = 60 FPS
//May be referred to as "interval" in the future.
var fps = 1000/60;

var timer = setInterval(animate, fps);

var square = new square();
square.color = "blue";
square.x = rand(2,canvas.width);
square.y = rand(1,canvas.height);
square.vx = rand(0,10);
square.vy = rand(0,10);


function animate()
{
	//erases old rectangle.
	context.clearRect(0,0,canvas.width,canvas.height);
	
	square.move();
	square.draw();
}