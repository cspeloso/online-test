//random number function/program
function rand(low,high)
{
	return Math.round(Math.random() * (high - low) + low);
}