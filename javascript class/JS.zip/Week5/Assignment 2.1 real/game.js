//game.js script
var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");

var interval = 1000/60;

var timer = setInterval(animate,interval);

var player1 = new GameObject(50,400,25,100,"black");

function animate()
{
	context.clearRect(0,0,canvas.width,canvas.height);
	

	if(w)
	{
		player1.y -= 8;
		console.log()
	}
	
	if(s)
	{
		player1.y += 8;
	}

	if(player1.bottom() > canvas.height)
	{
		player1.y = canvas.height - player1.height/2;
		console.log("colliding");
	}
	
	if(player1.top() < 0)
	{
		player1.y = 0 + player1.height/2;
		console.log("colliding");
	}
	
	player1.drawRect();
}