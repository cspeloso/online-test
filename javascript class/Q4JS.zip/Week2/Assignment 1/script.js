window.addEventListener("load",init)

var people =[
		{first:"Jason", last:"Vorhees", credit:"Friday the 13th"},
		{first:"Freddy", last:"Krueger", credit:"A Nightmare on Elm Street" },
		{first:"Roger", last:"Rabbit", credit:"Who Framed Roger Rabbit" },
		{first:"Kevin", last:"McCallister", credit:"Home Alone" },
		{first:"Godzilla", last:"King of The Monsters", credit:"Godzilla" },
		{first:"Buzz", last:"Lightyear", credit:"Toy Story" },
		{first:"Marion", last:"Cobretti", credit:"Cobra" }
	]
	



function init()
{
	
	for (var i = 0; i <= 6; i++)
	{
		//DIV creation part
		
		var tempDiv = document.createElement("DIV");
		
		tempDiv.setAttribute("id",String("div" + i));
		
		document.body.appendChild(tempDiv);
		
		document.getElementById("div" + i).className = "border";
		
		//paragraph part 1
		
		
		
		
		var pElement = document.createElement("p");
		
		var first = document.createTextNode(people[i].first);
		
		pElement.appendChild(first);
		
		tempDiv.appendChild(pElement);
		
		///////////////////////////////
		
		var pElement2 = document.createElement("p");
		
		var last = document.createTextNode(people[i].last);
		
		pElement2.appendChild(last);
		
		tempDiv.appendChild(pElement2);
		
		////////////////////////////////
		
		var pElement3 = document.createElement("p");
		
		var credit = document.createTextNode(people[i].credit);
		
		pElement3.appendChild(credit);
		
		tempDiv.appendChild(pElement3);
		
		
		
	}
	
	
	
	
	
	
}






















