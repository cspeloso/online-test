window.addEventListener("load",init)

function init()
{
	var body = document.querySelector("body");
	body.innerHTML = "";
	
	for (var i=0;i < 1000; i++)
	{
		/*var document.createElement("p");
		body.appendChild(p);*/
		
		body.innerHTML += "<p>This is a paragraph" + (i+1) + "</p>";
	}
}


/*var h1 = document.getElementById("title");

h1.innerHTML = "<i>Week 2 Demo</i>";
h1.style.color = "red";
h1.style.fontSize = "48px";

var p = document.getElementsByTagName("p");
console.log(p);
for(var i = 0; i < p.length; i++)
{
	//p[i].style.color = "pink";
	//p[i].className = "blue";
}

var pc = document.getElementsByClassName("orange");
console.log(PC);
*/