window.addEventListener("load",init)

//Use this Array of objects to complete the assignment.
var people =[
	{first:"Jason", last:"Vorhees", credit:"Friday the 13th"},
	{first:"Freddy", last:"Krueger", credit:"A Nightmare on Elm Street" },
	{first:"Roger", last:"Rabbit", credit:"Who Framed Roger Rabbit" },
	{first:"Kevin", last:"McCallister", credit:"Home Alone" },
	{first:"Godzilla", last:"King of The Monsters", credit:"Godzilla" },
	{first:"Buzz", last:"Lightyear", credit:"Toy Story" },
	{first:"Marion", last:"Cobretti", credit:"Cobra" }
]
	
var tempBody = document.getElementsByTagName('body');

function init()
{
	
	
	var str="";
	
	for (var i = 0;i < 6; i++)
	{
		str += ("<div id = '" + i + "' class='border'>");
		
		str += "<p>";
		
		str += people[i].first + " ";
		
		str += "</p>"
		
		str += "<p>";
		
		str += people[i].last + " ";
		
		str += "</p>";
		
		str += "<p>";
		
		str += people[i].credit;
		
		str += "</p>";
		
		str += "</div>";		
	}
		
	document.body.innerHTML = str;
	
	
	
	
	
}