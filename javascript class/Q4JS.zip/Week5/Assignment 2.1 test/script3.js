//another script
//Set Up the Canvas
var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");
//1000 ms or 1 second / FPS
var interval = 1000/60;
var player = new GameObject();
var timer = setInterval(animate,interval);

function animate()
{
	//erase screen
	context.clearRect(0,0,canvas.width,canvas.height);
	
	//move player right
	if(w)
	{
		console.log("moving up");
		player.y += 2;
	}
	
	if (s)
	{
		console.log("moving down");
		player.y -= 2;
	}
	
	//update screen
	player.drawRect();
}