//Declare my variables

var canvas;
var context;
var timer;
//1000 ms or 1 second / FPS
var interval = 1000/60;
var player;

	//Set Up the Canvas
	canvas = document.getElementById("canvas");
	context = canvas.getContext("2d");	
	
	//Instantiate the Player
	player = new Player();
	player.color = "blue";
	player.vx = 2;
	
	player2 = new Player();
	player2.y = player.height/2;
	player2.vx = 1;
	
	//Set the Animation Timer
	timer = setInterval(animate, interval);
	
	var currentState = "move";
	
	states = [];
	states["stop"] = function(){
		player.draw();
		player2.draw();
	}
	states["move"] = function(){
		player.move();
		player2.move();
		player.draw();
		player2.draw();
	}
	
	
	
	

function animate()
{
	//Erase the Screen
	context.clearRect(0,0,canvas.width, canvas.height);	
	
	if(player.x > canvas.width)
	{
		currentState = "stop";
	}
	
	states[currentState]();
	
	
	/*Move the Player
	player.move();
	player2.move();*/
	
	
	/*Update the Screen
	player.draw();
	player2.draw();*/
}
