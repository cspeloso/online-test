//random color function
function randColors()
{
	var color =""; 
	color += "rgb("; 
	color += Math.floor(Math.random()*255.9);
	color += ",";
	color += Math.floor(Math.random()*255.9);
	color += ",";
	color += Math.floor(Math.random()*255.9);
	color += ")";
	return color;
}