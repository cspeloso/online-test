//game script file
var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");

var player = new GameObject(canvas.width/2,(canvas.height - 75),50,50,"#ffff00");

var score = 0;

var scoreCounter = document.getElementById("scoreCounter");

var randomNumber = rand(1,10);

//hazards
var hazard1 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"orange",0,rand(3,10));
var hazard2 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"orange",0,rand(3,10));
var hazard3 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"orange",0,rand(3,10));
var hazard4 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"orange",0,rand(3,10));
var hazard5 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"orange",0,rand(3,10));

//items
var item1 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"blue",0,rand(3,10));
var item2 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"blue",0,rand(3,10));
var item3 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"blue",0,rand(3,10));
var item4 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"blue",0,rand(3,10));
var item5 = new GameObject(rand(30,canvas.width - 30),rand(-30,-canvas.height/2),30,30,"blue",0,rand(3,10));

var interval = 1000/60;

var timer = setInterval(animate,interval);

function animate()
{
	context.clearRect(0,0,canvas.width,canvas.height);
	
	if(a)
	{
		player.x -= 10;
	}
	
	if(d)
	{
		player.x += 10;
	}
	
	if(player.x > canvas.width - player.width/2)
	{
		player.x = canvas.width - player.width/2;
	}
	
	if(player.x < 0 + player.width/2)
	{
		player.x = 0 + player.width/2;
	}
	
	//if player hits hazard1
	if((hazard1.y + hazard1.height/2) >= (player.y - player.height/2) && (((hazard1.x + hazard1.width/2) >= (player.x - player.width/2)) && ((hazard1.x - hazard1.width/2) <= (player.x + player.width/2))))
	{
		player.color = "red";
	
		score = 0;
		
		resetHazardsItems();
		
		randomNumber = 0;
		
		hazard1.vy = 0;
		hazard2.vy = 0;
		hazard3.vy = 0;
		hazard4.vy = 0;
		hazard5.vy = 0;
		
		item1.vy = 0;
		item2.vy = 0;
		item3.vy = 0;
		item4.vy = 0;
		item5.vy = 0;
		
		var damage = setTimeout(playerHurt,500);
		
	}
	
	//if player hits hazard2
	if((hazard2.y + hazard2.height/2) >= (player.y - player.height/2) && (((hazard2.x + hazard2.width/2) >= (player.x - player.width/2)) && ((hazard2.x - hazard2.width/2) <= (player.x + player.width/2))))
	{
		player.color = "red";
	
		score = 0;
		
		resetHazardsItems();
		
		randomNumber = 0;
		
		hazard1.vy = 0;
		hazard2.vy = 0;
		hazard3.vy = 0;
		hazard4.vy = 0;
		hazard5.vy = 0;
		
		item1.vy = 0;
		item2.vy = 0;
		item3.vy = 0;
		item4.vy = 0;
		item5.vy = 0;
		
		var damage = setTimeout(playerHurt,500);
		
	}
	
	//if player hits hazard3
	if((hazard3.y + hazard3.height/2) >= (player.y - player.height/2) && (((hazard3.x + hazard3.width/2) >= (player.x - player.width/2)) && ((hazard3.x - hazard3.width/2) <= (player.x + player.width/2))))
	{
		player.color = "red";
	
		score = 0;
		
		resetHazardsItems();
		
		randomNumber = 0;
		
		hazard1.vy = 0;
		hazard2.vy = 0;
		hazard3.vy = 0;
		hazard4.vy = 0;
		hazard5.vy = 0;
		
		item1.vy = 0;
		item2.vy = 0;
		item3.vy = 0;
		item4.vy = 0;
		item5.vy = 0;
		
		var damage = setTimeout(playerHurt,500);
		
	}
	
	//if player hits hazard4
	if((hazard4.y + hazard4.height/2) >= (player.y - player.height/2) && (((hazard4.x + hazard4.width/2) >= (player.x - player.width/2)) && ((hazard4.x - hazard4.width/2) <= (player.x + player.width/2))))
	{
		player.color = "red";
	
		score = 0;
		
		resetHazardsItems();
		
		randomNumber = 0;
		
		hazard1.vy = 0;
		hazard2.vy = 0;
		hazard3.vy = 0;
		hazard4.vy = 0;
		hazard5.vy = 0;
		
		item1.vy = 0;
		item2.vy = 0;
		item3.vy = 0;
		item4.vy = 0;
		item5.vy = 0;
		
		var damage = setTimeout(playerHurt,500);
		
	}
	
	//if player hits hazard5
	if((hazard5.y + hazard5.height/2) >= (player.y - player.height/2) && (((hazard5.x + hazard5.width/2) >= (player.x - player.width/2)) && ((hazard5.x - hazard5.width/2) <= (player.x + player.width/2))))
	{
		player.color = "red";
	
		score = 0;
		
		resetHazardsItems();
		
		randomNumber = 0;
		
		hazard1.vy = 0;
		hazard2.vy = 0;
		hazard3.vy = 0;
		hazard4.vy = 0;
		hazard5.vy = 0;
		
		item1.vy = 0;
		item2.vy = 0;
		item3.vy = 0;
		item4.vy = 0;
		item5.vy = 0;
		
		var damage = setTimeout(playerHurt,500);
		
	}
	
	//if player hits item1
	if((item1.y + item1.height/2) >= (player.y - player.height/2) && (((item1.x + item1.width/2) >= (player.x - player.width/2)) && ((item1.x - item1.width/2) <= (player.x + player.width/2))))
	{
		player.color = "limegreen";
		
		score++;
		
		item1.x = rand(30,canvas.width - 30);
		
		item1.y = rand(-30,-canvas.height/2);
		
		randomNumber = rand(1,10);
		
		item1.vy = randomNumber;		
		
		var itemGet = setTimeout(playerGetItem,500);
				
	}
	
	//if player hits item2
	if((item2.y + item2.height/2) >= (player.y - player.height/2) && (((item2.x + item2.width/2) >= (player.x - player.width/2)) && ((item2.x - item2.width/2) <= (player.x + player.width/2))))
	{
		player.color = "limegreen";
		
		score++;
		
		item2.x = rand(30,canvas.width - 30);
		
		item2.y = rand(-30,-canvas.height/2);
		
		randomNumber = rand(1,10);
		
		item2.vy = randomNumber;		
		
		var itemGet = setTimeout(playerGetItem,500);
				
	}
	
	//if player hits item3
	if((item3.y + item3.height/2) >= (player.y - player.height/2) && (((item3.x + item3.width/2) >= (player.x - player.width/2)) && ((item3.x - item3.width/2) <= (player.x + player.width/2))))
	{
		player.color = "limegreen";
		
		score++;
		
		item3.x = rand(30,canvas.width - 30);
		
		item3.y = rand(-30,-canvas.height/2);
		
		randomNumber = rand(1,10);
		
		item3.vy = randomNumber;		
		
		var itemGet = setTimeout(playerGetItem,500);
				
	}
	
	//if player hits item4
	if((item4.y + item4.height/2) >= (player.y - player.height/2) && (((item4.x + item4.width/2) >= (player.x - player.width/2)) && ((item4.x - item4.width/2) <= (player.x + player.width/2))))
	{
		player.color = "limegreen";
		
		score++;
		
		item4.x = rand(30,canvas.width - 30);
		
		item4.y = rand(-30,-canvas.height/2);
		
		randomNumber = rand(1,10);
		
		item4.vy = randomNumber;		
		
		var itemGet = setTimeout(playerGetItem,500);
				
	}
	
	//if player hits item5
	if((item5.y + item5.height/2) >= (player.y - player.height/2) && (((item5.x + item5.width/2) >= (player.x - player.width/2)) && ((item5.x - item5.width/2) <= (player.x + player.width/2))))
	{
		player.color = "limegreen";
		
		score++;
		
		item5.x = rand(30,canvas.width - 30);
		
		item5.y = rand(-30,-canvas.height/2);
		
		randomNumber = rand(1,10);
		
		item5.vy = randomNumber;		
		
		var itemGet = setTimeout(playerGetItem,500);
				
	}
	
	
	hazard1.move();
	hazard2.move();
	hazard3.move();
	hazard4.move();
	hazard5.move();
	
	item1.move();
	item2.move();
	item3.move();
	item4.move();
	item5.move();
	
	player.move();
	
	hazard1.drawCircle();
	hazard2.drawCircle();
	hazard3.drawCircle();
	hazard4.drawCircle();
	hazard5.drawCircle();
	
	item1.drawRect();
	item2.drawRect();
	item3.drawRect();
	item4.drawRect();
	item5.drawRect();
	
	player.drawRect();
	
	scoreCounter.innerHTML = "<b>Score: </b>" + score;
}

function playerHurt()
{
	player.color = "yellow";
	
	randomNumber = rand(1,10);
	
	hazard1.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	hazard2.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	hazard3.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	hazard4.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	hazard5.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	item1.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	item2.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	item3.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	item4.vy = randomNumber;
	
	randomNumber = rand(1,10);
	
	item5.vy = randomNumber;
	//resetHazardsItems();
}

function playerGetItem()
{
	player.color = "yellow";
}

function resetHazardsItems()
{
	//resets the hazards x
	hazard1.x = rand(30,canvas.width - 30);
	hazard2.x = rand(30,canvas.width - 30);
	hazard3.x = rand(30,canvas.width - 30);
	hazard4.x = rand(30,canvas.width - 30);
	hazard5.x = rand(30,canvas.width - 30);
	
	//resets the hazards y
	hazard1.y = rand(-30,-canvas.height/2);
	hazard2.y = rand(-30,-canvas.height/2);
	hazard3.y = rand(-30,-canvas.height/2);
	hazard4.y = rand(-30,-canvas.height/2);
	hazard5.y = rand(-30,-canvas.height/2);
	
	//resets the items x
	item1.x = rand(30,canvas.width - 30);
	item2.x = rand(30,canvas.width - 30);
	item3.x = rand(30,canvas.width - 30);
	item4.x = rand(30,canvas.width - 30);
	item5.x = rand(30,canvas.width - 30);
	
	//resets the items y
	item1.y = rand(-30,-canvas.height/2);
	item2.y = rand(-30,-canvas.height/2);
	item3.y = rand(-30,-canvas.height/2);
	item4.y = rand(-30,-canvas.height/2);
	item5.y = rand(-30,-canvas.height/2);
	
	
}

























































