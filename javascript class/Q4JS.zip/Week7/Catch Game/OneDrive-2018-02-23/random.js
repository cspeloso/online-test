//random number function/program
function rand(low,high)
{
	var number;
	
	number = Math.round(Math.random() * (high - low) + low);
	
	return number;
}
